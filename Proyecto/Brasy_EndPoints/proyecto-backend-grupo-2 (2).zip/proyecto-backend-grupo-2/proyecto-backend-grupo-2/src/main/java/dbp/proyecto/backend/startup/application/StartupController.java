package dbp.proyecto.backend.startup.application;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import dbp.proyecto.backend.contribucionFinanciera.domain.ContribucionFinancieraDTO;
import dbp.proyecto.backend.contribucionFinanciera.domain.Contribucionfinanciera;
import dbp.proyecto.backend.publicacion.domain.Publicacion;
import dbp.proyecto.backend.startup.domain.Startup;
import dbp.proyecto.backend.startup.domain.StartupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/startups")
public class StartupController {
    @Autowired
    private StartupService startupService;

    //1. Crear una Startup
    @PostMapping
    public Startup createStartup(@RequestBody Startup startup) {
        return startupService.createStartup(startup);
    }

    //2. Eliminar una Startup
    @DeleteMapping("/{id}")
    public void deleteStartup(@PathVariable Long id) {
        startupService.deleteStartup(id);
    }

    //3. Actualizar datos de una Startup
    @PutMapping("/{id}")
    public Startup updateStartup(@PathVariable Long id, @RequestBody Startup startupDetails) {
        return startupService.updateStartup(id, startupDetails);
    }

    //4. Mostrar información de una Startup específica por su ID
    @GetMapping("/{id}")
    public Startup getStartupById(@PathVariable Long id) {
        return startupService.getStartupById(id);
    }

    //5. Listar las contribuciones financieras recibidas por una startup
    @GetMapping("/{id}/contribuciones")
    public List<ContribucionFinancieraDTO> getContribucionesByStartupId(@PathVariable Long id) {
        return startupService.getContribucionesByStartupId(id);
    }

    //6. Mostrar el total de contribuciones financieras de una startup
    @GetMapping("/{id}/total-contribuciones")
    public Double getTotalContribucionesByStartupId(@PathVariable Long id) {
        return startupService.getTotalContribucionesByStartupId(id);
    }

    //7. Obtener el estado de financiamiento de una startup
    @GetMapping("/{id}/estado-financiamiento")
    public String getEstadoDeFinanciamiento(@PathVariable Long id) {
        return startupService.getEstadoDeFinanciamiento(id);
    }

    //8. Actualizar el estado de financiamiento de una startup
    @PutMapping("/{id}/estado-financiamiento")
    public Startup updateEstadoDeFinanciamiento(@PathVariable Long id, @RequestBody String nuevoEstado) {
        return startupService.updateEstadoDeFinanciamiento(id, nuevoEstado);
    }

    //9. Buscar Startups por categoría
    @GetMapping("/categoria/{categoria}")
    public List<Startup> findByCategoria(@PathVariable String categoria) {
        return startupService.findByCategoria(categoria);
    }

    //10. Obtener todas las publicaciones de una startup
    @GetMapping("/{id}/publicaciones")
    public List<Publicacion> getPublicacionesByStartupId(@PathVariable Long id) {
        return startupService.getPublicacionesByStartupId(id);
    }

    //11. Listar todos los comentarios en una startup
    @GetMapping("/{id}/comentarios")
    public List<Comentarios> getComentariosByStartupId(@PathVariable Long id) {
        return startupService.getComentariosByStartupId(id);
    }
}
