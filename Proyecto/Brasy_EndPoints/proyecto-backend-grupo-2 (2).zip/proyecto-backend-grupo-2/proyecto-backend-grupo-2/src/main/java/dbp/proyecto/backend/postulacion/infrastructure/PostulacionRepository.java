package dbp.proyecto.backend.postulacion.infrastructure;

import dbp.proyecto.backend.postulacion.domain.Postulacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostulacionRepository extends JpaRepository<Postulacion, Long> {
    //4. Mostrar lista de postulaciones de una startup
    List<Postulacion> findByStartupId(Long startupId);

    //5. Filtrar postulaciones por estado
    List<Postulacion> findByEstado(String estado);
}
