package dbp.proyecto.backend.startup.domain;

public enum Fasedesarrollo {
    Incipiente, Emergente, Establecida, Consolidada
}
