package dbp.proyecto.backend.publicacion.infrastructure;

import dbp.proyecto.backend.publicacion.domain.Publicacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PublicacionRepository extends JpaRepository<Publicacion, Long> {
    //4. Listar publicaciones por orden de fecha
    @Query("SELECT p FROM Publicacion p ORDER BY p.fechaPublicacion DESC")
    List<Publicacion> findAllOrderByFechaPublicacionDesc();
}
