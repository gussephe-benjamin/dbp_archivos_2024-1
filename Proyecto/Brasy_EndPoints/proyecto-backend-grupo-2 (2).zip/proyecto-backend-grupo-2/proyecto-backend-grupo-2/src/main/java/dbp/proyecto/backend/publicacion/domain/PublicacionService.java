package dbp.proyecto.backend.publicacion.domain;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import dbp.proyecto.backend.like.domain.Like;
import dbp.proyecto.backend.publicacion.infrastructure.PublicacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PublicacionService {
    @Autowired
    private PublicacionRepository publicacionRepository;

    //1. Crear una Publicación
    public Publicacion createPublicacion(Publicacion publicacion) {
        return publicacionRepository.save(publicacion);
    }

    //2. Eliminar una Publicación
    public void deletePublicacion(Long id) {
        publicacionRepository.deleteById(id);
    }

    //3. Actualizar datos de una Publicación
    public Publicacion updatePublicacion(Long id, Publicacion publicacionDetails) {
        Optional<Publicacion> optionalPublicacion = publicacionRepository.findById(id);
        if (optionalPublicacion.isPresent()) {
            Publicacion publicacion = optionalPublicacion.get();
            publicacion.setTitulo(publicacionDetails.getTitulo());
            publicacion.setFechaPublicacion(publicacionDetails.getFechaPublicacion());
            return publicacionRepository.save(publicacion);
        } else {
            return null;
        }
    }

    //4. Listar publicaciones por orden de fecha
    public List<Publicacion> findAllOrderByFechaPublicacionDesc() {
        return publicacionRepository.findAllOrderByFechaPublicacionDesc();
    }

    //5. Mostrar comentarios de una publicación
    public List<Comentarios> getComentariosByPublicacionId(Long publicacionId) {
        Optional<Publicacion> optionalPublicacion = publicacionRepository.findById(publicacionId);
        return optionalPublicacion.map(Publicacion::getComentarios).orElse(null);
    }

    //6. Mostrar likes de una publicación
    public List<Like> getLikesByPublicacionId(Long publicacionId) {
        Optional<Publicacion> optionalPublicacion = publicacionRepository.findById(publicacionId);
        return optionalPublicacion.map(Publicacion::getLikes).orElse(null);
    }
}
