package dbp.proyecto.backend.contribucionFinanciera.domain;

import dbp.proyecto.backend.contribucionFinanciera.infrastructure.ContribucionfinancieraRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ContribucionfinancieraService {
    @Autowired
    private ContribucionfinancieraRepository contribucionFinancieraRepository;

    //1. Crear una contribución financiera
    public Contribucionfinanciera createContribucionFinanciera(Contribucionfinanciera contribucionFinanciera) {
        return contribucionFinancieraRepository.save(contribucionFinanciera);
    }

    //2. Actualizar datos de una contribución financiera
    public Contribucionfinanciera updateContribucionFinanciera(Long id, Contribucionfinanciera contribucionFinancieraDetails) {
        Optional<Contribucionfinanciera> optionalContribucionFinanciera = contribucionFinancieraRepository.findById(id);
        if (optionalContribucionFinanciera.isPresent()) {
            Contribucionfinanciera contribucionFinanciera = optionalContribucionFinanciera.get();
            contribucionFinanciera.setMonto(contribucionFinancieraDetails.getMonto());
            contribucionFinanciera.setEstado(contribucionFinancieraDetails.getEstado());
            contribucionFinanciera.setMedio_dePago(contribucionFinancieraDetails.getMedio_dePago());
            return contribucionFinancieraRepository.save(contribucionFinanciera);
        } else {
            return null;
        }
    }

    //3. Mostrar lista de contribuciones financieras de una startup
    public List<Contribucionfinanciera> getContribucionesByStartupId(Long startupId) {
        return contribucionFinancieraRepository.findByStartupId(startupId);
    }

    //4. Acumular el monto de todas las contribuciones financieras de una startup
    public Double sumMontoByStartupId(Long startupId) {
        return contribucionFinancieraRepository.sumMontoByStartupId(startupId);
    }
}
