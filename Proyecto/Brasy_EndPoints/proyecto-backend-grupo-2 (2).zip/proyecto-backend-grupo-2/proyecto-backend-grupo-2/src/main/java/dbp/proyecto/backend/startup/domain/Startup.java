package dbp.proyecto.backend.startup.domain;

import dbp.proyecto.backend.contribucionFinanciera.domain.MetodoPago;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import dbp.proyecto.backend.contribucionFinanciera.domain.Contribucionfinanciera;
import dbp.proyecto.backend.publicacion.domain.Publicacion;
import dbp.proyecto.backend.postulacion.domain.Postulacion;
import dbp.proyecto.backend.user.domain.User;
import java.util.Date;
import java.util.List;

@Entity
@Setter
@Getter
public class Startup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_startup;

    private String descripcion;
    private String nombre;
    private Float total_contribuciones_Financieras;

    @Temporal(TemporalType.DATE)
    private Date fecha_creacion;

    @Enumerated(EnumType.STRING)
    private Fasedesarrollo estado_de_Financiamiento;

    @Enumerated(EnumType.STRING)
    private Categorias categoria;

    @ManyToOne
    @JoinColumn(name = "creador_id") //creador = user
    private User creador;

    @OneToMany(mappedBy = "startup")
    private List<Publicacion> publicaciones;

    @OneToMany(mappedBy = "startup")
    private List<Contribucionfinanciera> contribuciones_Financieras;

    @OneToMany(mappedBy = "startup")
    private List<Postulacion> postulaciones_a_startup;

    public Object getEstadoDeFinanciamiento() {
        return estado_de_Financiamiento;
    }

    public void setEstadoDeFinanciamiento(String nuevoEstado) {
    }
}
