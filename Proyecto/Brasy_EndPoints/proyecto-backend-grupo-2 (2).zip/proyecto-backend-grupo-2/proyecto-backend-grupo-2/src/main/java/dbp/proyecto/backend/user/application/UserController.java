package dbp.proyecto.backend.user.application;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import dbp.proyecto.backend.contribucionFinanciera.domain.Contribucionfinanciera;
import dbp.proyecto.backend.postulacion.domain.Postulacion;
import dbp.proyecto.backend.publicacion.domain.Publicacion;
import dbp.proyecto.backend.startup.domain.Startup;
import dbp.proyecto.backend.user.domain.User;
import dbp.proyecto.backend.user.domain.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserService userService;

    // 1. Crear un usuario
    @PostMapping
    public User createUser(@RequestBody User user) {
        return userService.saveUser(user);
    }

    // 2. Eliminar un usuario
    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
    }

    // 3. Actualizar datos de un usuario
    @PutMapping("/{id}")
    public User updateUser(@PathVariable Long id, @RequestBody User userDetails) {
        return userService.updateUser(id, userDetails);
    }

    //4. Mostrar información personal del usuario
    @GetMapping("/{id}")
    public User getUserById(@PathVariable Long id) {
        return userService.getUserById(id);
    }

    //5. Listar las startups creadas por un usuario
    @GetMapping("/{id}/startups")
    public List<Startup> getUserStartups(@PathVariable Long id) {
        return userService.getUserStartups(id);
    }

    //6. Listar las postulaciones realizadas por un usuario
    @GetMapping("/{id}/postulaciones")
    public List<Postulacion> getUserPostulaciones(@PathVariable Long id) {
        return userService.getUserPostulaciones(id);
    }

    //7. Listar las startups en las que un usuario ha realizado una postulación
    @GetMapping("/{id}/postulacion/startups")
    public List<Startup> getUserPostulacionStartups(@PathVariable Long id) {
        return userService.getUserPostulacionStartups(id);
    }

    //8. Listar las publicaciones realizadas por un usuario
    @GetMapping("/{id}/publicaciones")
    public List<Publicacion> getUserPublicaciones(@PathVariable Long id) {
        return userService.getUserPublicaciones(id);
    }

    //9. Listar las contribuciones financieras de un usuario
    @GetMapping("/{id}/contribuciones")
    public List<Contribucionfinanciera> getUserContribuciones(@PathVariable Long id) {
        return userService.getUserContribuciones(id);
    }

    //10. Listar las publicaciones a las que un usuario ha dado like
    @GetMapping("/{id}/likes/publicaciones")
    public List<Publicacion> getUserLikedPublicaciones(@PathVariable Long id) {
        return userService.getUserLikedPublicaciones(id);
    }

    //11. Listar los comentarios realizados por un usuario
    @GetMapping("/{id}/comentarios")
    public List<Comentarios> getUserComentarios(@PathVariable Long id) {
        return userService.getUserComentarios(id);
    }
}
