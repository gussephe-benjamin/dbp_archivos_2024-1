package dbp.proyecto.backend.startup.infrastructure;

import dbp.proyecto.backend.contribucionFinanciera.domain.Contribucionfinanciera;
import dbp.proyecto.backend.startup.domain.Startup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StartupRepository extends JpaRepository<Startup, Long> {
    // Obtener las contribuciones financieras recibidas por una startup
    @Query("SELECT c FROM Contribucionfinanciera c WHERE c.startup.id = :startupId")
    List<Contribucionfinanciera> findContribucionesByStartupId(@Param("startupId") Long startupId);

    // Obtener el total de contribuciones financieras de una startup
    @Query("SELECT SUM(c.monto) FROM Contribucionfinanciera c WHERE c.startup.id = :startupId")
    Double findtotalContribucionesByStartupId(@Param("startupId") Long startupId);

    Double findTotalContribucionesByStartupId(Long startupId);

    //9. Buscar Startups por categoría
    List<Startup> findByCategoria(String categoria);
}
