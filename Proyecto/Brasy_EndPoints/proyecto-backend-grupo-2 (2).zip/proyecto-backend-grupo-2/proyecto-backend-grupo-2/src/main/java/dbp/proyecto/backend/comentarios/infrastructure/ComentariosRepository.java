package dbp.proyecto.backend.comentarios.infrastructure;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ComentariosRepository extends JpaRepository<Comentarios, Long> {

}
