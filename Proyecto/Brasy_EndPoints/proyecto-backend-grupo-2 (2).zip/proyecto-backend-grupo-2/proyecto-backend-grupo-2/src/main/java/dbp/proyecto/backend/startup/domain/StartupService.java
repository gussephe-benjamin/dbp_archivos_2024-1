package dbp.proyecto.backend.startup.domain;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import dbp.proyecto.backend.contribucionFinanciera.domain.ContribucionFinancieraDTO;
import dbp.proyecto.backend.contribucionFinanciera.domain.Contribucionfinanciera;
import dbp.proyecto.backend.publicacion.domain.Publicacion;
import dbp.proyecto.backend.startup.infrastructure.StartupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class StartupService {
    @Autowired
    private StartupRepository startupRepository;

    //1. Crear una Startup
    public Startup createStartup(Startup startup) {
        return startupRepository.save(startup);
    }

    //2. Eliminar una Startup
    public void deleteStartup(Long id) {
        startupRepository.deleteById(id);
    }

    //3. Actualizar datos de una Startup
    public Startup updateStartup(Long id, Startup startupDetails) {
        Optional<Startup> optionalStartup = startupRepository.findById(id);
        if (optionalStartup.isPresent()) {
            Startup startup = optionalStartup.get();
            startup.setDescripcion(startupDetails.getDescripcion());
            startup.setCategoria(startupDetails.getCategoria());
            startup.setTotal_contribuciones_Financieras(startupDetails.getTotal_contribuciones_Financieras());
            return startupRepository.save(startup);
        } else {
            return null;
        }
    }

    //4. Mostrar información de una Startup específica por su ID
    public Startup getStartupById(Long id) {
        return startupRepository.findById(id).orElse(null);
    }

    //5. Listar las contribuciones financieras recibidas por una startup
    public List<ContribucionFinancieraDTO> getContribucionesByStartupId(Long startupId) {
        List<Contribucionfinanciera> contribuciones = startupRepository.findContribucionesByStartupId(startupId);
        return contribuciones.stream()
                .map(c -> new ContribucionFinancieraDTO(c.getContribuyente().getNombre(), c.getContribuyente().getApellido(), c.getMonto(), c.getEstado(), c.getMedioDePago()))
                .collect(Collectors.toList()); //MetodoPago si esta presente en el DTO que cree
    }

    //6. Mostrar el total de contribuciones financieras de una startup
    public Double getTotalContribucionesByStartupId(Long startupId) {
        return startupRepository.findTotalContribucionesByStartupId(startupId);
    }

    //7. Obtener el estado de financiamiento de una startup
    public String getEstadoDeFinanciamiento(Long startupId) {
        Optional<Startup> optionalStartup = startupRepository.findById(startupId);
        return optionalStartup.map(Startup::getEstadoDeFinanciamiento).orElse(null);
    }

    //8. Actualizar el estado de financiamiento de una startup
    public Startup updateEstadoDeFinanciamiento(Long id, String nuevoEstado) {
        Optional<Startup> optionalStartup = startupRepository.findById(id);
        if (optionalStartup.isPresent()) {
            Startup startup = optionalStartup.get();
            startup.setEstadoDeFinanciamiento(nuevoEstado);
            return startupRepository.save(startup);
        } else {
            return null;
        }
    }

    //9. Buscar Startups por categoría
    public List<Startup> findByCategoria(String categoria) {
        return startupRepository.findByCategoria(categoria);
    }

    //10. Obtener todas las publicaciones de una startup
    public List<Publicacion> getPublicacionesByStartupId(Long startupId) {
        Optional<Startup> optionalStartup = startupRepository.findById(startupId);
        return optionalStartup.map(Startup::getPublicaciones).orElse(null);
    }

    //11. Listar todos los comentarios en una startup
    public List<Comentarios> getComentariosByStartupId(Long startupId) {
        Optional<Startup> optionalStartup = startupRepository.findById(startupId);
        if (optionalStartup.isPresent()) {
            return optionalStartup.get().getPublicaciones().stream()
                    .flatMap(publicacion -> publicacion.getComentarios().stream())
                    .collect(Collectors.toList());
        } else {
            return null;
        }
    }
}

