package dbp.proyecto.backend.postulacion.domain;

import dbp.proyecto.backend.startup.domain.Startup;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import dbp.proyecto.backend.user.domain.User;

@Entity
@Getter
@Setter
public class Postulacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_postulacion;

    private String descripcion;
    private String experiencia; //No entendi: Usuario.colaboracionstatups.List<starups>

    @Enumerated(EnumType.STRING)
    private Estado_postulacion estado;
    //private EstadoPostulacion ESTADO = EstadoPostulacion.Pendiente;

    @ManyToOne
    @JoinColumn(name = "postulante_id")
    private User postulante;

    @ManyToOne
    @JoinColumn(name = "startup_id")
    private Startup startup;

}
