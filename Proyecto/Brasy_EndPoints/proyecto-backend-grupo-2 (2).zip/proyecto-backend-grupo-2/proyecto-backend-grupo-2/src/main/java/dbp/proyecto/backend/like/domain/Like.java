package dbp.proyecto.backend.like.domain;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import dbp.proyecto.backend.publicacion.domain.Publicacion;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import dbp.proyecto.backend.user.domain.User;
import java.util.Date;

@Entity
@Setter
@Getter
public class Like {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_Like;

    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private User usuario;

    @ManyToOne
    @JoinColumn(name = "publicacion_id", nullable = true)
    private Publicacion publicacion;

    @ManyToOne
    @JoinColumn(name = "comentario_id", nullable = true)
    private Comentarios comentario;

    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaLike;

    @Enumerated(EnumType.STRING)
    private Tipo tipoDeLike;
    //private TipoLike tipoLike = TipoLike.Like;
}
