package dbp.proyecto.backend.postulacion.application;

import dbp.proyecto.backend.postulacion.domain.Postulacion;
import dbp.proyecto.backend.postulacion.domain.PostulacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/postulacion")
public class PostulacionController {
    @Autowired
    private PostulacionService postulacionService;

    //1. Crear una postulación
    @PostMapping
    public Postulacion createPostulacion(@RequestBody Postulacion postulacion) {
        return postulacionService.createPostulacion(postulacion);
    }

    //2. Eliminar una postulación
    @DeleteMapping("/{id}")
    public void deletePostulacion(@PathVariable Long id) {
        postulacionService.deletePostulacion(id);
    }

    //3. Actualizar datos de una postulación
    @PutMapping("/{id}")
    public Postulacion updatePostulacion(@PathVariable Long id, @RequestBody Postulacion postulacionDetails) {
        return postulacionService.updatePostulacion(id, postulacionDetails);
    }

    //4. Mostrar lista de postulaciones de una startup
    @GetMapping("/startup/{startupId}")
    public List<Postulacion> getPostulacionesByStartupId(@PathVariable Long startupId) {
        return postulacionService.getPostulacionesByStartupId(startupId);
    }

    //5. Filtrar postulaciones por estado
    @GetMapping("/estado/{estado}")
    public List<Postulacion> getPostulacionesByEstado(@PathVariable String estado) {
        return postulacionService.getPostulacionesByEstado(estado);
    }

}
