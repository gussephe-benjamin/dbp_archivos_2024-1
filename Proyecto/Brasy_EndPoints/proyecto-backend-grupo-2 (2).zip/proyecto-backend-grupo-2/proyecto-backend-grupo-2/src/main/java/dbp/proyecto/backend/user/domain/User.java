package dbp.proyecto.backend.user.domain;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import dbp.proyecto.backend.like.domain.Like;
import dbp.proyecto.backend.publicacion.domain.Publicacion;
import jakarta.persistence.*;
import dbp.proyecto.backend.contribucionFinanciera.domain.Contribucionfinanciera;
import dbp.proyecto.backend.postulacion.domain.Postulacion;
import dbp.proyecto.backend.startup.domain.Startup;
import lombok.Getter;
import lombok.Setter;
import java.util.List;

@Entity
@Getter
@Setter
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_usuario;

    private String nombre;
    private String apellido;

    @Column(unique = true) //Especifica que el correo debe de ser unico en la BD
    private String correo;

    private String pais;
    private String ciudad;
    private String distrito;
    private String profesion;

    @OneToMany(mappedBy = "user")
    private List<Startup> startups;

    @OneToMany(mappedBy = "user")
    private List<Postulacion> postulaciones;

    @OneToMany(mappedBy = "user")
    private List<Contribucionfinanciera> contribucionesFinancieras_Realizadas;

    @OneToMany(mappedBy = "user")
    private List<Like> likes_dados;

    @OneToMany(mappedBy = "user")
    private List<Comentarios> comentarios_dados;

    public List<Publicacion> getPublicaciones() {
        return List.of();
    }

    public List<Contribucionfinanciera> getContribucionesfinancieras() {
        return List.of();
    }
}
