package dbp.proyecto.backend.like.domain;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import dbp.proyecto.backend.comentarios.infrastructure.ComentariosRepository;
import dbp.proyecto.backend.like.infrastructure.LikeRepository;
import dbp.proyecto.backend.publicacion.domain.Publicacion;
import dbp.proyecto.backend.publicacion.infrastructure.PublicacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class LikeService {
    @Autowired
    private LikeRepository likeRepository;
    @Autowired
    private PublicacionRepository publicacionRepository;
    @Autowired
    private ComentariosRepository comentariosRepository;

    //1. Generar un tipo de like a una publicación
    public Like likePublicacion(Long publicacionId, Like like) {
        Optional<Publicacion> optionalPublicacion = publicacionRepository.findById(publicacionId);
        if (optionalPublicacion.isPresent()) {
            like.setPublicacion(optionalPublicacion.get());
            return likeRepository.save(like);
        } else {
            return null;
        }
    }

    //2. Generar un tipo de like a un comentario
    public Like likeComentario(Long comentarioId, Like like) {
        Optional<Comentarios> optionalComentario = comentariosRepository.findById(comentarioId);
        if (optionalComentario.isPresent()) {
            like.setComentario(optionalComentario.get());
            return likeRepository.save(like);
        } else {
            return null;
        }
    }

    //3. Eliminar un like de una publicación
    public void deleteLikeFromPublicacion(Long likeId) {
        Optional<Like> optionalLike = likeRepository.findById(likeId);
        if (optionalLike.isPresent() && optionalLike.get().getPublicacion() != null) {
            likeRepository.deleteById(likeId);
        }
    }

    //4. Eliminar un like de un comentario
    public void deleteLikeFromComentario(Long likeId) {
        Optional<Like> optionalLike = likeRepository.findById(likeId);
        if (optionalLike.isPresent() && optionalLike.get().getComentario() != null) {
            likeRepository.deleteById(likeId);
        }
    }

    //5. Mostrar qué usuarios han dado like a una publicación
    public List<Like> getLikesByPublicacionId(Long publicacionId) {
        return likeRepository.findByPublicacionId(publicacionId);
    }

    //6. Mostrar qué usuarios han dado like a un comentario
    public List<Like> getLikesByComentarioId(Long comentarioId) {
        return likeRepository.findByComentarioId(comentarioId);
    }
}
