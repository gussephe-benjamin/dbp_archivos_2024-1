package dbp.proyecto.backend.contribucionFinanciera.infrastructure;

import dbp.proyecto.backend.contribucionFinanciera.domain.Contribucionfinanciera;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ContribucionfinancieraRepository extends JpaRepository<Contribucionfinanciera, Long> {
    //3. Obtener lista de contribuciones financieras de una startup
    List<Contribucionfinanciera> findByStartupId(Long startupId);

    //4. Acumular el monto de todas las contribuciones financieras de una startup
    @Query("SELECT SUM(c.monto) FROM Contribucionfinanciera c WHERE c.startup.id = :startupId")
    Double sumMontoByStartupId(@Param("startupId") Long startupId);
}
