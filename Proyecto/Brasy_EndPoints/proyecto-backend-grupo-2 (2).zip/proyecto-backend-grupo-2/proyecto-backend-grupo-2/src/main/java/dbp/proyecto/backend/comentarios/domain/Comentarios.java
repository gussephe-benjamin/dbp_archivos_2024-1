package dbp.proyecto.backend.comentarios.domain;

import dbp.proyecto.backend.publicacion.domain.Publicacion;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import dbp.proyecto.backend.like.domain.Like;
import dbp.proyecto.backend.user.domain.User;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

@Entity
@Setter
@Getter
public class Comentarios {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_Comentario;

    private String mensaje;

    @ManyToOne
    @JoinColumn(name = "publicacion_id")
    private Publicacion publicacion;

    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private User autor;

    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaCreacion;

    @OneToMany(mappedBy = "comentario")
    private List<Like> likes;
}
