package dbp.proyecto.backend.user.domain;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import dbp.proyecto.backend.contribucionFinanciera.domain.Contribucionfinanciera;
import dbp.proyecto.backend.postulacion.domain.Postulacion;
import dbp.proyecto.backend.publicacion.domain.Publicacion;
import dbp.proyecto.backend.startup.domain.Startup;
import dbp.proyecto.backend.user.infrastructure.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
import static dbp.proyecto.backend.like.domain.Tipo.Like;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    /*
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }*/

    // 1. Crear un usuario
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    // 2. Eliminar un usuario
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    // 3. Actualizar datos de un usuario
    public User updateUser(Long id, User userDetails) {
        User user = userRepository.findById(id).orElse(null);
        if (user != null) {
            user.setNombre(userDetails.getNombre());
            user.setApellido(userDetails.getApellido());
            user.setCorreo(userDetails.getCorreo());
            user.setPais(userDetails.getPais());
            user.setCiudad(userDetails.getCiudad());
            user.setDistrito(userDetails.getDistrito());
            return userRepository.save(user);
        }
        return null;
    }

    //4. Mostrar información personal del usuario
    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    //5. Listar las startups creadas por un usuario
    public List<Startup> getUserStartups(Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        return user != null ? user.getStartups() : null;
    }

    //6. Listar las postulaciones realizadas por un usuario
    public List<Postulacion> getUserPostulaciones(Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        return user != null ? user.getPostulaciones() : null;
    }

    //7. Obtener todas las startups en las que un usuario ha realizado una postulación
    public List<Startup> getUserPostulacionStartups(Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        return user != null ? user.getPostulaciones().stream().map(Postulacion::getStartup).distinct().collect(Collectors.toList()) : null;
    }

    //8. Listar las publicaciones realizadas por un usuario
    public List<Publicacion> getUserPublicaciones(Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        return user != null ? user.getPublicaciones() : null;
    }

    //9. Obtener todas las contribuciones financieras realizadas por un usuario
    public List<Contribucionfinanciera> getUserContribuciones(Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        return user != null ? user.getContribucionesfinancieras() : null;
    }

    //10. Obtener todas las publicaciones a las que un usuario ha dado like
    public List<Publicacion> getUserLikedPublicaciones(Long userId) {
        User user = userRepository.findById(userId).orElse(null); //No entindo pq no puede acceder a Publicacion si ya hay @Setter y @Getter
        return user != null ? user.getLikes_dados().stream().map(Like::getPublicacion).distinct().collect(Collectors.toList()) : null;
    }

    //11. Obtener todos los comentarios realizados por un usuario
    public List<Comentarios> getUserComentarios(Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        return user != null ? user.getComentarios_dados() : null;
    }
}


