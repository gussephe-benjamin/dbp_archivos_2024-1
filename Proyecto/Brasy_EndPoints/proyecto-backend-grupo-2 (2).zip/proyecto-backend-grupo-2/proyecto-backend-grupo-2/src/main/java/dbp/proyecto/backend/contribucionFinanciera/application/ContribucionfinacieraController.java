package dbp.proyecto.backend.contribucionFinanciera.application;

import dbp.proyecto.backend.contribucionFinanciera.domain.Contribucionfinanciera;
import dbp.proyecto.backend.contribucionFinanciera.domain.ContribucionfinancieraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/contribucionfinaciera")
public class ContribucionfinacieraController {
    @Autowired
    private ContribucionfinancieraService contribucionfinancieraService;

    //1. Crear una contribución financiera
    @PostMapping
    public Contribucionfinanciera createContribucionFinanciera(@RequestBody Contribucionfinanciera contribucionFinanciera) {
        return contribucionfinancieraService.createContribucionFinanciera(contribucionFinanciera);
    }

    //2. Actualizar datos de una contribución financiera
    @PutMapping("/{id}")
    public Contribucionfinanciera updateContribucionFinanciera(@PathVariable Long id, @RequestBody Contribucionfinanciera contribucionFinancieraDetails) {
        return contribucionfinancieraService.updateContribucionFinanciera(id, contribucionFinancieraDetails);
    }

    //3. Mostrar lista de contribuciones financieras de una startup
    @GetMapping("/startup/{startupId}")
    public List<Contribucionfinanciera> getContribucionesByStartupId(@PathVariable Long startupId) {
        return contribucionfinancieraService.getContribucionesByStartupId(startupId);
    }

    //4. Acumular el monto de todas las contribuciones financieras de una startup
    @GetMapping("/startup/{startupId}/total-monto")
    public Double sumMontoByStartupId(@PathVariable Long startupId) {
        return contribucionfinancieraService.sumMontoByStartupId(startupId);
    }
}
