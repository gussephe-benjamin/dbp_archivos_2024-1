package dbp.proyecto.backend.contribucionFinanciera.domain;

public enum MetodoPago {
    Bcp,Interbank,Visa,MasterCad,IziPay,YAPE,PLIN
}
