package dbp.proyecto.backend.postulacion.domain;

public enum Estado_postulacion {
    Aceptado,Rechazado,Pendiente
}
