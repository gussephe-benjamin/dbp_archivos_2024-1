package dbp.proyecto.backend.publicacion.domain;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import dbp.proyecto.backend.like.domain.Like;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import dbp.proyecto.backend.startup.domain.Startup;
import dbp.proyecto.backend.user.domain.User;

import java.util.Date;
import java.util.List;

@Entity
@Setter
@Getter
public class Publicacion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_publicacion;

    private String titulo;

    @Temporal(TemporalType.TIMESTAMP)
    private Date fechaPublicacion;

    @ManyToOne
    @JoinColumn(name = "startup_id") //Nombre de la columna en la BD
    private Startup startup;

    @ManyToOne
    @JoinColumn(name = "autor_id")
    private User autor;

    @OneToMany(mappedBy = "publicacion", cascade = CascadeType.ALL, orphanRemoval = true) //Si se elimina comentario, tmb de la BD
    private List<Like> likes;

    @OneToMany(mappedBy = "publicacion", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comentarios> comentarios;
}
