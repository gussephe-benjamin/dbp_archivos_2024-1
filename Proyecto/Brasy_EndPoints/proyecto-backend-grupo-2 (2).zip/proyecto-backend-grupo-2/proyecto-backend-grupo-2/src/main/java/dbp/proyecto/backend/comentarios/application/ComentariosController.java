package dbp.proyecto.backend.comentarios.application;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import dbp.proyecto.backend.comentarios.domain.ComentariosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
@RequestMapping("/api/comentarios")
public class ComentariosController {
    @Autowired
    private ComentariosService comentarioService;

    //1. Crear un comentario a una publicación
    @PostMapping("/publicacion/{publicacionId}")
    public Comentarios createComentario(@PathVariable Long publicacionId, @RequestBody Comentarios comentario) {
        return comentarioService.createComentario(publicacionId, comentario);
    }

    //2. Mostrar la fecha del comentario de una publicación
    @GetMapping("/{comentarioId}/fecha")
    public Date getFechaComentario(@PathVariable Long comentarioId) {
        return comentarioService.getFechaComentario(comentarioId);
    }

    //3. Eliminar un comentario a una publicación
    @DeleteMapping("/{comentarioId}")
    public void deleteComentario(@PathVariable Long comentarioId) {
        comentarioService.deleteComentario(comentarioId);
    }

    //4. Editar parcialmente un comentario después de realizarlo
    @PatchMapping("/{comentarioId}")
    public Comentarios updateComentarioParcial(@PathVariable Long comentarioId, @RequestBody String nuevoMensaje) {
        return comentarioService.updateComentarioParcial(comentarioId, nuevoMensaje);
    }
}
