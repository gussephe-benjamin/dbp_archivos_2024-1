package dbp.proyecto.backend.like.domain;

public enum Tipo {
    Like, MeEncanta, MeAsombra;

}
