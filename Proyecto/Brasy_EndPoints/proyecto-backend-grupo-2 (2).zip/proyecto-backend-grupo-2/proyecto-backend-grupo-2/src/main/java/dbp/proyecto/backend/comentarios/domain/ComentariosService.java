package dbp.proyecto.backend.comentarios.domain;

import dbp.proyecto.backend.comentarios.infrastructure.ComentariosRepository;
import dbp.proyecto.backend.publicacion.domain.Publicacion;
import dbp.proyecto.backend.publicacion.infrastructure.PublicacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Date;
import java.util.Optional;

@Service
public class ComentariosService {
    @Autowired
    private ComentariosRepository comentariosRepository;
    @Autowired
    private PublicacionRepository publicacionRepository;

    //1. Crear un comentario a una publicación
    public Comentarios createComentario(Long publicacionId, Comentarios comentario) {
        Optional<Publicacion> optionalPublicacion = publicacionRepository.findById(publicacionId);
        if (optionalPublicacion.isPresent()) {
            comentario.setPublicacion(optionalPublicacion.get());
            comentario.setFechaCreacion(new Date());
            return comentariosRepository.save(comentario);
        } else {
            return null;
        }
    }

    //2. Mostrar la fecha del comentario de una publicación
    public Date getFechaComentario(Long comentarioId) {
        Optional<Comentarios> optionalComentario = comentariosRepository.findById(comentarioId);
        return optionalComentario.map(Comentarios::getFechaCreacion).orElse(null);
    }

    //3. Eliminar un comentario a una publicación
    public void deleteComentario(Long comentarioId) {
        comentariosRepository.deleteById(comentarioId);
    }

    //4. Editar parcialmente un comentario después de realizarlo
    public Comentarios updateComentarioParcial(Long comentarioId, String nuevoMensaje) {
        Optional<Comentarios> optionalComentario = comentariosRepository.findById(comentarioId);
        if (optionalComentario.isPresent()) {
            Comentarios comentario = optionalComentario.get();
            comentario.setMensaje(nuevoMensaje);
            return comentariosRepository.save(comentario);
        } else {
            return null;
        }
    }
}
