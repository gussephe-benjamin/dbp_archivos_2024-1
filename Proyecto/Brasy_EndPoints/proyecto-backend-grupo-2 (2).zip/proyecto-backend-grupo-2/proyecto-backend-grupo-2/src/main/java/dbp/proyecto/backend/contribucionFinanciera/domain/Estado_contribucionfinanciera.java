package dbp.proyecto.backend.contribucionFinanciera.domain;

public enum Estado_contribucionfinanciera {
    Aceptado, Rechazado, Pendiente
}
