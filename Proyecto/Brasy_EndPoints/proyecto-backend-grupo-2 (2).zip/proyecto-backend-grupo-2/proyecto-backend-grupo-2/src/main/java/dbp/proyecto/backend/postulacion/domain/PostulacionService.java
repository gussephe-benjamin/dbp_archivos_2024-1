package dbp.proyecto.backend.postulacion.domain;

import dbp.proyecto.backend.postulacion.infrastructure.PostulacionRepository;
import dbp.proyecto.backend.user.domain.User;
import dbp.proyecto.backend.user.infrastructure.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class PostulacionService {
    @Autowired
    private PostulacionRepository postulacionRepository;

    @Autowired
    private UserRepository userRepository;

    //1. Crear una postulación
    public Postulacion createPostulacion(Postulacion postulacion) {
        Postulacion newPostulacion = postulacionRepository.save(postulacion);
        notifyStartupOwnerAboutNewPostulacion(newPostulacion);
        return newPostulacion;
    }

    //2. Eliminar una postulación
    public void deletePostulacion(Long id) {
        postulacionRepository.deleteById(id);
    }

    //3. Actualizar datos de una postulación
    public Postulacion updatePostulacion(Long id, Postulacion postulacionDetails) {
        Optional<Postulacion> optionalPostulacion = postulacionRepository.findById(id);
        if (optionalPostulacion.isPresent()) {
            Postulacion postulacion = optionalPostulacion.get();
            postulacion.setDescripcion(postulacionDetails.getDescripcion());
            postulacion.setExperiencia(postulacionDetails.getExperiencia());
            postulacion.setEstado(postulacionDetails.getEstado());
            Postulacion updatedPostulacion = postulacionRepository.save(postulacion);
            notifyUserAboutPostulacionStatus(updatedPostulacion);
            return updatedPostulacion;
        } else {
            return null;
        }
    }

    //4. Mostrar lista de postulaciones de una startup
    public List<Postulacion> getPostulacionesByStartupId(Long startupId) {
        return postulacionRepository.findByStartupId(startupId);
    }

    //5. Filtrar postulaciones por estado
    public List<Postulacion> getPostulacionesByEstado(String estado) {
        return postulacionRepository.findByEstado(estado);
    }

    //6. Notificar al usuario sobre el estado de su postulación
    private void notifyUserAboutPostulacionStatus(Postulacion postulacion) {
        User user = postulacion.getPostulante();
        //enviar un email
        System.out.println("Notificando a " + user.getNombre() + " sobre el estado de su postulación.");
    }

    //7. Notificar al dueño de la startup sobre nuevas postulaciones
    private void notifyStartupOwnerAboutNewPostulacion(Postulacion postulacion) {
        User owner = postulacion.getStartup().getCreador();
        //envia un gmail
        System.out.println("Notificando a " + owner.getNombre() + " sobre una nueva postulación.");
    }
}
