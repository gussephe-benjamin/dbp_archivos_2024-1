package dbp.proyecto.backend.contribucionFinanciera.domain;

import dbp.proyecto.backend.startup.domain.Startup;
import dbp.proyecto.backend.user.domain.User;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class Contribucionfinanciera {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_Contribucionfinanciera;

    private Float monto;

    @Enumerated(EnumType.STRING)
    private Estado_contribucionfinanciera estado;

    @Enumerated(EnumType.STRING)
    private MetodoPago medio_dePago;

    @ManyToOne
    @JoinColumn(name = "usuario_id")
    private User contribuyente;

    @ManyToOne
    @JoinColumn(name = "startup_id")
    private Startup startup;
}
