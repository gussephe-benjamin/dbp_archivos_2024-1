package dbp.proyecto.backend.like.application;

import dbp.proyecto.backend.like.domain.Like;
import dbp.proyecto.backend.like.domain.LikeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/like")
public class LikeController {
    @Autowired
    private LikeService likeService;

    //1. Generar un tipo de like a una publicación
    @PostMapping("/publicacion/{publicacionId}")
    public Like likePublicacion(@PathVariable Long publicacionId, @RequestBody Like like) {
        return likeService.likePublicacion(publicacionId, like);
    }

    //2. Generar un tipo de like a un comentario
    @PostMapping("/comentario/{comentarioId}")
    public Like likeComentario(@PathVariable Long comentarioId, @RequestBody Like like) {
        return likeService.likeComentario(comentarioId, like);
    }

    //3. Eliminar un like de una publicación
    @DeleteMapping("/publicacion/{likeId}")
    public void deleteLikeFromPublicacion(@PathVariable Long likeId) {
        likeService.deleteLikeFromPublicacion(likeId);
    }

    //4. Eliminar un like de un comentario
    @DeleteMapping("/comentario/{likeId}")
    public void deleteLikeFromComentario(@PathVariable Long likeId) {
        likeService.deleteLikeFromComentario(likeId);
    }

    //5. Mostrar qué usuarios han dado like a una publicación
    @GetMapping("/publicacion/{publicacionId}")
    public List<Like> getLikesByPublicacionId(@PathVariable Long publicacionId) {
        return likeService.getLikesByPublicacionId(publicacionId);
    }

    //6. Mostrar qué usuarios han dado like a un comentario
    @GetMapping("/comentario/{comentarioId}")
    public List<Like> getLikesByComentarioId(@PathVariable Long comentarioId) {
        return likeService.getLikesByComentarioId(comentarioId);
    }
}
