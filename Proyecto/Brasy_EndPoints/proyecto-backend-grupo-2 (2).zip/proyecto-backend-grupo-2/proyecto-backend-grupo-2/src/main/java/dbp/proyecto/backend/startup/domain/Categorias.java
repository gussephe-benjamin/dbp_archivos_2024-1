package dbp.proyecto.backend.startup.domain;

public enum Categorias {
    PorDefinir,Salud, Tecnología, Social, Comercio, Educación, Finanzas, Viajes, Alimentación, Moda
}
