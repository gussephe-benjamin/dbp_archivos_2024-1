package dbp.proyecto.backend.like.infrastructure;

import dbp.proyecto.backend.like.domain.Like;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface LikeRepository extends JpaRepository<Like, Long> {
    // 5. Obtener lista de likes por publicación
    List<Like> findByPublicacionId(Long publicacionId);

    //6. Obtener lista de likes por comentario
    List<Like> findByComentarioId(Long comentarioId);
}
