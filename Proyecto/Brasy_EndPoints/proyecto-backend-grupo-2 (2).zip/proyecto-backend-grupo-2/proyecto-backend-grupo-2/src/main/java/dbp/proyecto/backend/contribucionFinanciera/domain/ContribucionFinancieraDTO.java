package dbp.proyecto.backend.contribucionFinanciera.domain;

public class ContribucionFinancieraDTO {
    private String nombre;
    private String apellido;
    private float monto;
    private String estado;
    private String medioDePago;

    public ContribucionFinancieraDTO(String nombre, String apellido, float monto, String estado, String medioDePago) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.monto = monto;
        this.estado = estado;
        this.medioDePago = medioDePago;
    }
}
