package dbp.proyecto.backend.publicacion.application;

import dbp.proyecto.backend.comentarios.domain.Comentarios;
import dbp.proyecto.backend.like.domain.Like;
import dbp.proyecto.backend.publicacion.domain.Publicacion;
import dbp.proyecto.backend.publicacion.domain.PublicacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/publicacion")
public class PublicacionController {
    @Autowired
    private PublicacionService publicacionService;

    //1. Crear una Publicación
    @PostMapping
    public Publicacion createPublicacion(@RequestBody Publicacion publicacion) {
        return publicacionService.createPublicacion(publicacion);
    }

    //2. Eliminar una Publicación
    @DeleteMapping("/{id}")
    public void deletePublicacion(@PathVariable Long id) {
        publicacionService.deletePublicacion(id);
    }

    //3. Actualizar datos de una Publicación
    @PutMapping("/{id}")
    public Publicacion updatePublicacion(@PathVariable Long id, @RequestBody Publicacion publicacionDetails) {
        return publicacionService.updatePublicacion(id, publicacionDetails);
    }

    //4. Listar publicaciones por orden de fecha
    @GetMapping("/orden-fecha")
    public List<Publicacion> findAllOrderByFechaPublicacionDesc() {
        return publicacionService.findAllOrderByFechaPublicacionDesc();
    }

    //5. Mostrar comentarios de una publicación
    @GetMapping("/{id}/comentarios")
    public List<Comentarios> getComentariosByPublicacionId(@PathVariable Long id) {
        return publicacionService.getComentariosByPublicacionId(id);
    }

    //6. Mostrar likes de una publicación
    @GetMapping("/{id}/likes")
    public List<Like> getLikesByPublicacionId(@PathVariable Long id) {
        return publicacionService.getLikesByPublicacionId(id);
    }
}
