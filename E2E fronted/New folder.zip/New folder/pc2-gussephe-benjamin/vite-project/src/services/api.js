import axios from 'axios';

const URL = 'http://18.117.176.220';

export const fetchlogin = async (body) => {
    const response = await axios.post(`${URL}/api/auth/login`, {
        email: body.email,
        password: body.password
    });
    const access_token = response.data.access_token;
    if (access_token) {
        localStorage.setItem('access_token', access_token);
    } else {
        throw new Error('Token is not available');
    }
    return response;
  
};

export const fetchregister = async (body) => {

    const response = await axios.post(`${URL}/api/auth/register`,body);
    const access_token = response.data.access_token;
    localStorage.setItem('access_token', access_token);
    return response;
} 

export const FetchPostObject = async (body) => {

    console.log(body)

    console.log("llego")

    const access_token = localStorage.getItem('access_token')

    console.log("llego")

    const response = await axios.post(`${URL}/api/products/`, body,
        {headers: {'Authorization': `Bearer ${access_token}`},});
     
    console.log("llego")
    return response
}


export const FetchPatchObject = async (products_id,body) => {

    const access_token = localStorage.getItem('access_token')

    const response = await axios.patch(`${URL}/api/products/${products_id}`,body,{ // url del api de creación 
        headers: {
            'Authorization': `Bearer ${access_token}`,
        },
    });
}

export const FetchDeleteObject = async (products_id) =>{
    const access_token = localStorage.getItem('access_token')

    const response = await axios.delete(`${URL}/api/products/${products_id}`,{ // url del api de creación 
        headers: {
            'Authorization': `Bearer ${access_token}`,
        },
    });
}

export const FetchGetObjetById = async (products_id) => {

    const access_token = localStorage.getItem('access_token')

    const response = await axios.get(`${URL}/object/${products_id}`,{headers:{'Authorization ': `Bearer ${access_token}`},});

    return response.data

}


