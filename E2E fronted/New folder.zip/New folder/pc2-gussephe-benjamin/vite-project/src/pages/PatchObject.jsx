import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { FetchPatchObject } from '../services/api';

 const PatchObject = () => {
    const[id,setId] = useState('')
    const[description, setDesc] = useState('')
    const[image_url, setImage] = useState('')
    const[name, setName] = useState('')
    const[price, setPrice] = useState('')
    const[quantity, setQuantity] = useState('')


  const handleSubmit = async() =>{

    try{  

    const res = await FetchPatchObject(id,{description,name,price,quantity})

      console.log('se actualizaron los datos del objeto con id: ', id )
      alert('registro completo')
      navigate('/dashboard')

    }catch(error){
      console.log(error)
    }
  }

  const navigate = useNavigate();
  return (
    <>
    <div>PatchObject</div>

    <form onSubmit={handleSubmit}>

    <input 
      type='text'
      value={description}
      onChange={(e)=>setDesc(e.target.value)}
      placeholder='NEW description'
      required
      />

    <input 
      type='id'
      value={id}
      onChange={(e)=>setId(e.target.value)}
      placeholder='ID'
      required
      />
    
      <input 
      type='text'
      value={image_url}
      onChange={(e)=>setImage(e.target.value)}
      placeholder='NEW imagen_url'
      required
      />

    <input 
      type='text'
      value={name}
      onChange={(e)=>setName(e.target.value)}
      placeholder='NEW name'
      required
    />

    <input 
      type='number'
      value={price}
      onChange={(e)=>setPrice(e.target.value)}
      placeholder='NEW price'
      required
    />

    <input 
      type='number'
      value={quantity}
      onChange={(e)=>setQuantity(e.target.value)}
      placeholder='NEW quanty'
      required
    />

      <button type='submit'> Registrar Nuevo Objeto</button>
    </form>
    <button onClick={()=> navigate('/dashboard') }> DASHBOARD </button>
    </>
  )
}

export default PatchObject