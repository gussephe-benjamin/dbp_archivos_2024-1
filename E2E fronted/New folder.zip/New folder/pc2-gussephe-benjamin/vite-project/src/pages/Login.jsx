import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchlogin } from '../services/api';

const Login = () => {
    const navigate = useNavigate();
    const [username, setUser] = useState('');
    const [password, setPassword] = useState('');

    const handleClick = async () => {
        
        // Aquí puedes agregar la lógica para enviar las credenciales al servidor
        const res =  fetchlogin({password,username})
        console.log("Login successful:", res);
        console.log("Email:", username);
        console.log("Password:", password);
        navigate('/dashboard')
      }

  return (
    <>
       <label htmlFor="email">Username:</label>
      <input 
        type="text"
        value={username}
        onChange={(e) => setUser(e.target.value)}
      />
      <label htmlFor="password">Password:</label>
      <input 
        type="password"
        id="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleClick}>
        Click me!
      </button> 

      <button onClick={()=>navigate('/auth/register')}>
            Register
      </button> 
      </>
  )
}

export default Login
