import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom';
import { fetchregister } from '../services/api'


const Register = () => {
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [full_name, setFullname] = useState('');
    const [password, setPassword] = useState('');
    const [username, setUsername] = useState('');
   


    const handleSubmit  = async (e) => {
        e.preventDefault();
        try{
            console.log("paso1")
            const res = await fetchregister({email,full_name,password,username});
            navigate('/auth/login')
            console.log("paso2")
            alert('Resgistrado con exito');
            console.log(res.data)
        } catch(error){
            console.log('Se registró el error: ',error)
        }
    }
    
  return (
   <form onSubmit={handleSubmit}>

        <input 
        type='email'
        placeholder='Email'
        value={email}
        onChange={(e)=>setEmail(e.target.value)}
        required
        />


        <input 
        type='text'
        placeholder='full_name'
        value={full_name}
        onChange={(e)=>setFullname(e.target.value)}
        required
        />

        <input 
        type='password'
        placeholder='password'
        value={password}
        onChange={(e)=>setPassword(e.target.value)}
        required
        />

        <input 
        type='text'
        placeholder='Username '
        value={username}
        onChange={(e)=>setUsername(e.target.value)}
        required
        />
       

        <button type='submit'>
            Registrar
        </button>

        <button onClick={()=>navigate('/auth/login')}>
            Login
      </button> 
   </form>
  );
};

export default Register
