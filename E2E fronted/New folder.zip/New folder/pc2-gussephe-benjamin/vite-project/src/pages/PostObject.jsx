import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom';
import { FetchPostObject } from '../services/api';

 const PostObject = () => {
  const navigate = useNavigate();

    const[description, setDesc] = useState('')
    const[image_url, setImage] = useState('')
    const[name, setName] = useState('')
    const[price, setPrice] = useState('')
    const[quantity, setQuantity] = useState('')



  const handleSubmit = async() =>{

    try{  

      const res = await FetchPostObject({description,image_url,name,price,quantity})
      alert('registro completo')
      navigate('/dashboard')

    }catch(error){
      console.log(error)
    }

  } 

  return (

    <>
    <div>PostObject</div>

    <form onSubmit={handleSubmit}>

    <input 
      type='text'
      value={description}
      onChange={(e)=>setDesc(e.target.value)}
      placeholder='description'
      required
      />
    
      <input 
      type='text'
      value={image_url}
      onChange={(e)=>setImage(e.target.value)}
      placeholder='imagen_url'
      required
      />

      
    <input 
      type='text'
      value={name}
      onChange={(e)=>setName(e.target.value)}
      placeholder='name'
      required
    />

    <input 
      type='number'
      value={price}
      onChange={(e)=>setPrice(e.target.value)}
      placeholder='price'
      required
    />

    <input 
      type='number'
      value={quantity}
      onChange={(e)=>setQuantity(e.target.value)}
      placeholder='quanty'
      required
    />

      <button type='submit'> Registrar Nuevo Objeto</button>
    </form>
    <button onClick={()=> navigate('/dashboard') }> DASHBOARD </button>
    </>
  )
}

export default PostObject

