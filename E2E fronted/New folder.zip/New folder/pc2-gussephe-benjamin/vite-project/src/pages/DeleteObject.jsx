import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom';
import { FetchDeleteObject } from '../services/api';

const DeleteObject = () => {
  const navigate = useNavigate();
  const[product_id,setproduct_id] = useState('')

  const handleSubmit = async() =>{
    try{  
         const res = await FetchDeleteObject(product_id);

      console.log('se eliminó corrctamente el objeto con id: ', product_id )
     
      alert('Se elimino correctamente el objeto')
      navigate('/dashboard')

    }catch(error){
      console.log(error)
    }
  }

  return (

    <>
    <div>DeleteObject</div>

    <input 
      type='id'
      value={product_id}
      onChange={(e)=>setproduct_id(e.target.value)}
      placeholder='ID del objeto '
      required
    />

    <button onClick={handleSubmit} > Eliminar</button>

    <button onClick={()=> navigate('/dashboard') }> DASHBOARD</button>
    </>
    
  )
}

export default DeleteObject;