package org.e2e.e2e.ride.domain;

public enum Status {
    REQUESTED, ACCEPTED, IN_PROGRESS, COMPLETED, CANCELLED
}
